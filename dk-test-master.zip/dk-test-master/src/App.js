import React from 'react';
import './App.css';
import "./styles/Scroll.css"

import Header from "./components/Header"
import DataSet from "./components/DataSet"

function App() {
  return (
    <div className="App">
    <Header />
    <DataSet />
    </div>
  );
}

export default App;
