import React from "react";
import { Radar } from "react-chartjs-2";

export default function RadarChart(props) {
  const radarData = {
    labels: [
      "Facebook",
      "Twitter",
      "Instagram",
      "Snapchat",
      "Gmail",
      "Tinder",
      "Amazon",
      "YouTube"
      
    ],
    datasets: [
      {
        label: "Visits %",
        borderColor: "rgba(68, 108, 179, 1)",
        data: props.componentData,
        
      }
    ],
  };

  return (
    <div>
      <div style={{ width: 700, height: 350, marginLeft: "100px" }} className="linebox">
        <Radar
          options={{
            responsive: true
          }}
          data={radarData}
        />
      </div>
      <hr></hr>
    </div>
  );
}
