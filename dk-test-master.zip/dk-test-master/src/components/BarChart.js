import React from "react";
import { Bar } from "react-chartjs-2";

export default function BarChart(props) {
  const barData = {
    labels: [
      "Facebook",
      "Twitter",
      "Instagram",
      "Snapchat",
      "Gmail",
      "Tinder",
      "Amazon",
      "YouTube"
    ],
    datasets: [
      {
        label: "Visits %",
        borderColor: "rgba(21, 174, 239, 1)",
        backgroundColor: "rgba(21, 174, 239, 1)",
        data: props.componentData
      }
    ]
  };

  return (
    <div>
      <div style={{ width: 700, height: 350, marginLeft: "100px" }} className="linebox">
        <Bar
          options={{
            responsive: true,
            scales: {
              
              yAxes: [
                {
                  scaleLabel: {
                    display: true,
                    labelString: "Websites Vists - %"
                  }
                }
              ]
            }
          }}
          data={barData}
        />
      </div>
      <hr></hr>
    </div>
  );
}
