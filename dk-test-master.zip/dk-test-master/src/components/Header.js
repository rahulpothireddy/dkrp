import React from "react";
import "../styles/Header.css"

export default function Header() {

  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-light bg-blue">
        <a className="navbar-brand" href="https://www.youtube.com/">
          <h3>DataKwip Test</h3>
          
        </a>
      </nav>
    </div>
  );
}
