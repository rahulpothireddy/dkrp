import React from "react";
import ResultCharts from "./ResultCharts";

export default class DataSet extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      chartType: "",
      expenses: {
        fb: "",
        twit: "",
        insta: "",
        snap: "",
        gmail: "",
        tind: "",
        amz: "",
        yout: ""
      },
      radarData: [],
      lineData: [],
      barData: [],
      pieData: [],
    };

    this.handleExpenseChange = this.handleExpenseChange.bind(this);
    this.handleTemplateChange = this.handleTemplateChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleTemplateChange(event) {
    const { name, value } = event.target;

    this.setState({
      [name]: value,
    });
  }

  handleExpenseChange(event) {
    const { name, value } = event.target;

    this.setState((prevState) => ({
      expenses: { ...prevState.expenses, [name]: value },
    }));
  }

  

  handleSubmit(e) {
    e.preventDefault();
    const expenseSet = Object.values(this.state.expenses).map((val) =>
      parseInt(val, 10)
    );

    if (this.state.chartType === "line") {
      let lineD = this.state.lineData;
      lineD.push(expenseSet);
      this.setState({
        lineData: lineD,
      });
    } else if (this.state.chartType === "pie") {
      let pieD = this.state.pieData;
      pieD.push(expenseSet);
      this.setState({
        pieData: pieD,
      });
    } else if (this.state.chartType === "radar") {
      let radarD = this.state.radarData;
      radarD.push(expenseSet);
      this.setState({
        radarData: radarD,
      });
    } else if (this.state.chartType === "bar") {
      let barD = this.state.barData;
      barD.push(expenseSet);
      this.setState({
        barData: barD,
      });
    }
  }

  render() {
    return (

      <div className="row">
        <div className="col-md-3" style={{borderRight: "1px solid lightgray", height: "700px"}}>
          <form className="row" style={{ marginLeft: 20 }}>
            <h5 className="mb-3">Select Type of Chart:</h5>
            <div className="form-row">
              <div className="form-group col-md-11">
                <select
                  style={{ width: 275 }}
                  name="chartType"
                  className="form-control"
                  value={this.state.chartType}
                  onChange={this.handleTemplateChange}
                  required
                >
                  <option value="" disabled selected>
                    Select your option
                  </option>
                  <option value="bar">Bar</option>
                  <option value="pie">Pie</option>
                  <option value="radar">Radar</option>
                  <option value="line">Line</option>  
                </select>
              </div>
            </div>
          </form>
          <form
            className="row"
            style={{ marginLeft: 20 }}
            onSubmit={this.handleSubmit}
          >
            <h5 className="mb-3 mt-2">Website Visit Percentage Here:</h5>

            <div className="form-row">
              <div className="form-group col-md-5">
                <input
                  type="text"
                  className="form-control"
                  id="facebook"
                  placeholder="Facebook"
                  name="fb"
                  value={this.state.expenses.fb}
                  onChange={this.handleExpenseChange}
                  required
                />
              </div>
              <div className="form-group col-md-5">
                <input
                  type="text"
                  className="form-control"
                  id="twitter"
                  placeholder="Twitter"
                  name="twit"
                  value={this.state.expenses.twit}
                  onChange={this.handleExpenseChange}
                  required
                />
              </div>
            </div>
            <div className="form-row">
              <div className="form-group col-md-5">
                <input
                  type="text"
                  className="form-control"
                  id="instagram"
                  placeholder="Instagram"
                  name="insta"
                  value={this.state.expenses.insta}
                  onChange={this.handleExpenseChange}
                  required
                />
              </div>
              <div className="form-group col-md-5">
                <input
                  type="text"
                  className="form-control"
                  id="snapchat"
                  placeholder="Snapchat"
                  name="snap"
                  value={this.state.expenses.snap}
                  onChange={this.handleExpenseChange}
                  required
                />
              </div>
            </div>
            <div className="form-row">
              <div className="form-group col-md-5">
                <input
                  type="text"
                  className="form-control"
                  id="gmail"
                  placeholder="Gmail"
                  name="gmail"
                  value={this.state.expenses.gmail}
                  onChange={this.handleExpenseChange}
                  required
                />
              </div>
              <div className="form-group col-md-5">
                <input
                  type="text"
                  className="form-control"
                  id="tinder"
                  placeholder="Tinder"
                  name="tind"
                  value={this.state.expenses.tind}
                  onChange={this.handleExpenseChange}
                  required
                />
              </div>
            </div>
            <div className="form-row">
              <div className="form-group col-md-5">
                <input
                  type="text"
                  className="form-control"
                  id="amazon"
                  placeholder="Amazon"
                  name="amz"
                  value={this.state.expenses.amz}
                  onChange={this.handleExpenseChange}
                  required
                />
              </div>
              <div className="form-group col-md-5">
                <input
                  type="text"
                  className="form-control"
                  id="youtube"
                  placeholder="YouTube"
                  name="yout"
                  value={this.state.expenses.yout}
                  onChange={this.handleExpenseChange}
                  required
                />
              </div>
            </div>
            
            <div className="form-row">
              <div className="form-group col-md-12 ml-4">
                <input
                  type="submit"
                  value="Generate Chart"
                  className="btn btn-lg btn-success"
                />
              </div>
            </div>
            
          </form>
        </div>

        <div className="col-md-8 scroll">
          <ResultCharts
            line={this.state.lineData}
            bar={this.state.barData}
            pie={this.state.pieData}
            radar={this.state.radarData}
          />
        </div>
      </div>
      
      );
  }
}
