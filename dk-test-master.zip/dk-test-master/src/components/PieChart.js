import React from "react";
import { Pie } from "react-chartjs-2";

export default function PieChart(props) {
  const pieData = {
    datasets: [
      {
        label: "Visits %",
        data: props.componentData,
        backgroundColor: [
          "rgba(245, 102, 0, 1)",
          "rgba(199, 0, 57, 1.1)",
          "rgba(82, 82, 82, 1)",
          "rgba(0, 145, 255, 1)",
          "rgba(85, 170, 108, 1)",
          "rgba(147, 89, 247, 1)",
          "rgba(14, 180, 8, 1)",
          "rgba(235, 122, 205, 1)"
        ]
      }
    ],
    labels: [
      "Facebook",
      "Twitter",
      "Instagram",
      "Snapchat",
      "Gmail",
      "Tinder",
      "Amazon",
      "YouTube"
    ]
  };

  return (
    <div>
      <div style={{ width: 700, height: 350, marginLeft: "100px" }} className="linebox">
        <Pie
          options={{
            responsive: true
          }}
          data={pieData}
        />
      </div>
      <hr></hr>
    </div>
  );
}
