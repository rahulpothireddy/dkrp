import React from "react";
import { Line } from "react-chartjs-2";

export default function LineChart(props) {
  const lineData = {
    labels: [
      "Facebook",
      "Twitter",
      "Instagram",
      "Snapchat",
      "Gmail",
      "Tinder",
      "Amazon",
      "YouTube"
    ],
    datasets: [
      {
        label: "Visits %",
        borderColor: "rgba(73, 186, 13, 1)",
        backgroundColor: "rgba(248, 243, 155, 1)",
        data: props.componentData
      }
    ]
  };

  return (
    <div>
      <div style={{ width: 700, height: 350, marginLeft: "100px"}} className="linebox">
        
        <Line
          options={{
            responsive: true,
            scales: {
              
              yAxes: [
                {
                  scaleLabel: {
                    display: true,
                    labelString: "Websites Vists - %"
                  }
                }
              ]
            }
          }}
          data={lineData}
        />
      </div>
      <hr></hr>
    </div>
  );
}
