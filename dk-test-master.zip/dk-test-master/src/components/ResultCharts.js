import React from "react";
import LineChart from "./LineChart";
import BarChart from "./BarChart";
import PieChart from "./PieChart";
import RadarChart from "./RadarChart";

export default function ResultCharts(props) {
  const lineComponents = props.line.map((data, index) => (
    <LineChart key={index} componentData={data} />
  ));

  const barComponents = props.bar.map((data, index) => (
    <BarChart key={index} componentData={data} />
  ));

  const pieComponents = props.pie.map((data, index) => (
    <PieChart key={index} componentData={data} />
  ));

  const radarComponents = props.radar.map((data, index) => (
    <RadarChart key={index} componentData={data} />
  ));

  const zeroLength = () => {
    if ((!Array.isArray(lineComponents) || !lineComponents.length) && (!Array.isArray(barComponents) || !barComponents.length) && (!Array.isArray(pieComponents) || !pieComponents.length) && (!Array.isArray(radarComponents) || !radarComponents.length)) {
      return true
    } else {
      return false
    }
  }

  const itemsMessage = zeroLength() && <h4 style={{color: "gray", marginTop: "250px", marginLeft: "450px"}}>Charts Here ...</h4>

  return (
    <div className="row">
      {itemsMessage}
      {barComponents}
      {pieComponents}
      {radarComponents}
      {lineComponents}     
    </div>
  );
}
